import os

path = os.path.dirname(os.path.realpath(__file__)) + '\\'
maxsize = 10 * 1024 * 1000  # 10兆？


def single_to_double(string):
    if len(string) == 2:
        ST = [''] * 2
        ST[0] = string
        return ST
    lis = int(len(string) / 2) * ['']
    y = 0
    for x in range(0, len(string), 2):
        try:
            lis[y] = string[x] + string[x + 1]
        except:
            print(string)
            lis[y] = string[x] + string[x + 1]
            exit(1)
        y = y + 1
    return lis


def to_list(byte):
    hex_list = ("{:02X}".format(int(c)) for c in byte)  # 定义变量接受文件内容
    return list(hex_list)


def 递归(path1, 长度, 内容):
    files2 = os.listdir(path1)
    for file in files2:
        # print(path1+file+'666')
        try:
            f = open(path1 + file, 'rb')
            文件大小 = os.stat(path1 + file).st_size
            if 文件大小 <= maxsize:
                if 内容 in ','.join(to_list(f.read())):
                    print(path1 + file)
            else:
                print(path + file + '\t大于50m')
            f.close()
        except:
            递归(path1 + file + '\\', 长度, 内容)


# 字符串 = input('请输入需要搜索的内容')
字符串 = '　そして、僕らは続きを……'
长度 = len(bytes(字符串, 'CP932').hex()) / 2
内容 = bytes(字符串, 'CP932').hex().upper()
内容 = single_to_double(内容)
内容 = ','.join(内容)
print(内容)
files1 = os.listdir(path)
print(files1)
for file in files1:
    # print(path+file)
    try:
        f = open(path + file, 'rb')
        文件大小 = os.stat(path + file).st_size
        if 文件大小 <= maxsize:
            if 内容 in ','.join(to_list(f.read())):
                print(path + file)
        else:
            print(path + file + '\t大于50m')
        # else:
        #     oversize = f.read(maxsize)
        #     oversizeadd = 0
        #     oversize = to_list(oversize)
        #     maxo = len(oversize)
        #     add = oversize[maxo - 2 * 长度:]
        #     oversize = ','.join()
        #     while oversize:
        #         oversize = f.read(maxsize)
        #         oversize = to_list(oversize)
        #         if oversizeadd != 0:
        #             add = oversize[maxo - 2 * 长度:]
        #             oversize1 = len(oversize) + 2 * 长度
        #             j = 0
        #             for i in range(len(add)):
        #                 oversize1[j] = add[i]
        #                 j = j + 1
        #             for i in range(len(oversize)):
        #                 oversize1[j] = oversize[i]
        #                 j = j + 1
        #         oversize = ','.join()
        f.close()
    except:
        递归(path + file + '\\', 长度, 内容)
